# Flask Starter Website

A clean, production-ready Flask website with pages, a contact form, and SQLite storage.

## Features
- Flask + SQLAlchemy
- SQLite database stored in `instance/site.db`
- Jinja2 templates with a minimal dark UI
- Gunicorn + Procfile for deployment to Render/Railway/Heroku-style platforms

## Local Setup

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python -c "from app import db, app; 
from app import Message; 
app.app_context().push(); 
db.create_all()"
flask --app app run
```

Visit http://127.0.0.1:5000

## Environment Variables
- `SECRET_KEY` (optional): set your own secret

## Deploy (Render example)
1. Create a new **Render Web Service**.
2. Build command: `pip install -r requirements.txt`
3. Start command: `gunicorn app:app`
4. Add environment variable `SECRET_KEY`.

## GitHub Quick Start
```bash
git init
git add .
git commit -m "Initial Flask site"
git branch -M main
git remote add origin https://github.com/<YOUR_USERNAME>/<YOUR_REPO>.git
git push -u origin main
```
