document.addEventListener("DOMContentLoaded", () => {
  console.log("Flask site ready.");
});
