from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import os

app = Flask(__name__, instance_relative_config=True)

# Config
app.config.from_mapping(
    SECRET_KEY=os.environ.get("SECRET_KEY", "dev-secret-change-me"),
    SQLALCHEMY_DATABASE_URI=os.environ.get("DATABASE_URL", f"sqlite:///{os.path.join(app.instance_path, 'site.db')}"),
    SQLALCHEMY_TRACK_MODIFICATIONS=False,
)

# Ensure instance folder exists
try:
    os.makedirs(app.instance_path, exist_ok=True)
except OSError:
    pass

db = SQLAlchemy(app)

class Message(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), nullable=False)
    email = db.Column(db.String(120), nullable=False)
    body = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f"<Message {self.id} {self.email}>"

@app.route("/")
def home():
    return render_template("home.html", title="Home")

@app.route("/about")
def about():
    return render_template("about.html", title="About")

@app.route("/projects")
def projects():
    demo_projects = [
        {"name": "PolyChat (Demo)", "desc": "AI-powered chat translator concept.", "link": "#"},
        {"name": "Portfolio Site", "desc": "This Flask website.", "link": "#"},
        {"name": "To-Do App", "desc": "Simple CRUD app using Flask + SQLite.", "link": "#"}
    ]
    return render_template("projects.html", title="Projects", projects=demo_projects)

@app.route("/contact", methods=["GET", "POST"])
def contact():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip()
        body = request.form.get("message", "").strip()
        if not name or not email or not body:
            flash("Please fill in all fields.", "error")
        else:
            msg = Message(name=name, email=email, body=body)
            db.session.add(msg)
            db.session.commit()
            flash("Message sent successfully!", "success")
            return redirect(url_for("contact"))
    messages = Message.query.order_by(Message.created_at.desc()).limit(5).all()
    return render_template("contact.html", title="Contact", messages=messages)

if __name__ == "__main__":
    # Initialize DB on first run
    with app.app_context():
        db.create_all()
    app.run(host="0.0.0.0", port=5000, debug=True)
